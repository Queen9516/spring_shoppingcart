Install Requirement

JDK 8+
Eclipse 2021.12
Maven 3.6+

- Extract Zip File.
- Eclipse Start
- Import/Project/Maven/ Select Extracted Folder
- Maven build
- Run Application
- http://localhost:8080

Password for login
	admin	admin
